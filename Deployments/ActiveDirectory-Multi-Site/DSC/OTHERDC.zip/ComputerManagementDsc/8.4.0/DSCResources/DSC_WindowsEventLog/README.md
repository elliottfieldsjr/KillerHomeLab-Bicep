# Description

This resource allows the configuration of the Logsize, Logmode, SecurityDescriptor,
RetentionDays and enabled/disabled the state of a specified Windows Event Log.
It is also possible to set the maximum size of the Windows Event Log.
