# Description

The xDnsServerRootHint DSC resource manages root hints on a Domain Name System (DNS) server.
